<?php
if (Auth::user()->dashboard_style == "light") {
    $bg="light";
    $text = "dark";
} else {
    $bg="dark";
    $text = "light";
}

?>

@extends('layouts.app')

    @section('content')
        @include('user.topmenu')
        @include('user.sidebar')
        <div class="main-panel bg-{{$bg}}">
            <div class="content bg-{{$bg}}">
                <div class="page-inner">
                    <div class="mt-2 mb-4">


                        @if(Session::has('getAnouc') && Session::get('getAnouc') == "true" )
                            @if ($settings->enable_annoc == "on")
                                <h5 id="ann" class="text-{{$text}}op-7 mb-4">{{$settings->update}}</h5>
                                <script type="text/javascript">
                                    var announment = $("#ann").html();
                                    console.log(announment);
                                    swal({
                                        title: "Annoucement!",
                                        text: announment,
                                        icon: "info",
                                        buttons: {
                                            confirm: {
                                                text: "Okay",
                                                value: true,
                                                visible: true,
                                                className: "btn btn-info",
                                                closeModal: true
                                            }
                                        }
                                    });
                                </script>  
                            @endif
                            {{session()->forget('getAnouc')}}
                        @endif

                    </div>
                    @if(Session::has('message'))
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <i class="fa fa-info-circle"></i> {{ Session::get('message') }}
                            </div>
                        </div>
                    </div>
                    @endif
        
                    @if(count($errors) > 0)
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="alert alert-danger alert-dismissable" role="alert" >
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                @foreach ($errors->all() as $error)
                                <i class="fa fa-warning"></i> {{ $error }}
                                @endforeach
                            </div>
                        </div>
                    </div>
                    @endif
                    <!-- Beginning of  Dashboard Stats  -->
                    <h3 class="text-{{$text}} ">Dashboard</h3>
                    <h5 class="text-{{$text}}">Home <i class="fa fa-chevron-right" style="font-size: 12px;"></i> <span style="font-size: 13px;">Dashboard</span></h5>

                    <div class="row row-card-no-pd bg-{{$bg}} shadow-lg">
                        <div class="col-sm-6 col-md-3">
                            <div class="card card-stats card-round bg-{{$bg}}">
                                <div class="card-body ">
                                    <div class="row">
                                        <div class="col-5">
                                            <div class="icon-big text-center">
                                                <i class="fa fa-download  text-warning "></i>
                                            </div>
                                        </div>
                                        <div class="col-7 col-stats">
                                            <div class="numbers">
                                                <p class="card-category">Deposits</p>
                                                <h4 class="card-title text-{{$text}}">@foreach($deposited as $deposited)
                                                @if(!empty($deposited->count))
                                                {{$settings->currency}}{{$deposited->count}}
                                                @else
                                                {{$settings->currency}}0.00
                                                @endif
                                                    @endforeach
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="card card-stats card-round bg-{{$bg}}">
                                <div class="card-body ">
                                    <div class="row">
                                        <div class="col-5">
                                            <div class="icon-big text-center">
                                                <i class="fa fa-upload text-danger"></i>
                                            </div>
                                        </div>
                                        <div class="col-7 col-stats">
                                            <div class="numbers">
                                                <p class="card-category">Withdrawals</p>
                                                <h4 class="card-title text-{{$text}}">{{$settings->currency}}{{ number_format(Auth::user()->roi, 2, '.', ',')}}</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="card card-stats card-round bg-{{$bg}}">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-5">
                                            <div class="icon-big text-center">
                                                <i class="flaticon-coins text-success"></i>
                                            </div>
                                        </div>
                                        <div class="col-7 col-stats">
                                            <div class="numbers">
                                                <p class="card-category">Ledger Balance</p>
                                                <h4 class="card-title text-{{$text}}">{{$settings->currency}} {{ number_format($total_bonus->bonus, 2, '.', ',')}}</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="card card-stats card-round bg-{{$bg}}">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-5">
                                            <div class="icon-big text-center">
                                                <i class="flaticon-coins text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col-7 col-stats">
                                            <div class="numbers">
                                                <p class="card-category">Current Balance</p>
                                                <h4 class="card-title text-{{$text}}">{{$settings->currency}}{{ number_format(Auth::user()->ref_bonus, 2, '.', ',')}}</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{--<div class="col-sm-6 col-md-3">--}}
                            {{--<div class="card card-stats card-round bg-{{$bg}}">--}}
                                {{--<div class="card-body ">--}}
                                    {{--<div class="row">--}}
                                        {{--<div class="col-5">--}}
                                            {{--<div class="icon-big text-center">--}}
                                                {{--<i class="flaticon-coins text-success"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="col-7 col-stats">--}}
                                            {{--<div class="numbers">--}}
                                                {{--<p class="card-category">Balance</p>--}}
                                                {{--<h4 class="card-title text-{{$text}}">{{$settings->currency}}{{ number_format(Auth::user()->account_bal, 2, '.', ',')}}</h4> <br>--}}

                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div class="col-sm-6 col-md-3">--}}
                            {{--<div class="card card-stats card-round bg-{{$bg}}">--}}
                                {{--<div class="card-body">--}}
                                    {{--<div class="row">--}}
                                        {{--<div class="col-5">--}}
                                            {{--<div class="icon-big text-center">--}}
                                                {{--<i class="fa fa-envelope text-danger"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="col-7 col-stats">--}}
                                            {{--<div class="numbers">--}}
                                                {{--<p class="card-category">Total Packages</p>--}}
                                                {{--@if(count($user_plan)>0)--}}
                                                {{--<h4 class="card-title text-{{$text}}">{{$user_plan->count()}}</h4>--}}
                                                {{--@else--}}
                                                {{--<h4 class="card-title text-{{$text}}">0</h4>--}}
                                                {{--@endif--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div class="col-sm-6 col-md-3">--}}
                            {{--<div class="card card-stats card-round bg-{{$bg}}">--}}
                                {{--<div class="card-body">--}}
                                    {{--<div class="row">--}}
                                        {{--<div class="col-5">--}}
                                            {{--<div class="icon-big text-center">--}}
                                                {{--<i class="fa fa-envelope-open text-primary"></i>--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                        {{--<div class="col-7 col-stats">--}}
                                            {{--<div class="numbers">--}}
                                                {{--<p class="card-category">Active Packages</p>--}}

                                                {{--@if(count($user_plan_active)>0)--}}
                                                {{--<h4 class="card-title text-{{$text}}">{{$user_plan_active->count()}}</h4>--}}
                                                {{--@else--}}
                                                {{--<h4 class="card-title text-{{$text}}">0</h4>--}}
                                                {{--@endif--}}
                                            {{--</div>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    </div>
                    <!-- Beginning of chart -->
                    <div class="tradingview-widget-container">
                        <div class="tradingview-widget-container__widget"></div>
                        <div class=""><a href="" rel="noopener" target="_blank"><span class="blue-text">
                         <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                      {
                          "symbols": [
                          {
                              "proName": "FOREXCOM:SPXUSD",
                              "title": "S&P 500"
                          },
                          {
                              "proName": "FOREXCOM:NSXUSD",
                              "title": "Nasdaq 100"
                          },
                          {
                              "proName": "FX_IDC:EURUSD",
                              "title": "EUR/USD"
                          },
                          {
                              "proName": "BITSTAMP:BTCUSD",
                              "title": "BTC/USD"
                          },
                          {
                              "proName": "BITSTAMP:ETHUSD",
                              "title": "ETH/USD"
                          }
                      ],
                          "showSymbolLogo": true,
                          "colorTheme": "light",
                          "isTransparent": false,
                          "displayMode": "adaptive",
                          "locale": "en"
                      }
                      </script>
                                </span>
                            </a>

                        </div>

                        <!-- Beginning of chart -->
                        <div class="row">
                            <div class="col-12">
                                <div id="chart-page">
                                    @include('includes.cryptochart')
                                </div>
                            </div>
                        </div>
                <!-- end of chart -->
                </div>
                </div>
    @endsection


    
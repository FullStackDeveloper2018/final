<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wdmethods extends Model
{

 
}

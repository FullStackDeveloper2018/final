<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cp_transactions extends Model
{

 
}
